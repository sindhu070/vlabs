#!/bin/bash
sudo apt-get update
sudo apt-get install -y octave3.2
sudo apt-get install -y gnuplot
sudo apt-get install -y gnuplot-nox
sudo apt-get install -y gnuplot-x11
cd /var/www
chmod -R 777 exp1 exp2 exp3 exp4 exp5 exp6 exp7 exp8 exp9 exp10

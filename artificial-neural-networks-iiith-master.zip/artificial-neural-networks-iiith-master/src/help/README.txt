Congrats !!

* You have successfully downloaded and extracted the
  ui.tgz .


* Now run makefile by the following commands inside the 'ui/src' folder to
  create the build directory :

          make clean all 

* Now, open ui/build/index.html in the browser to test the template.

* For any further doubts refer to the help that has been provided 
  inside the build/help/index.html. 

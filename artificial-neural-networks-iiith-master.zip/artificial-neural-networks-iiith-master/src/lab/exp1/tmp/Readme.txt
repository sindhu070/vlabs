This directory contains all the temporary log files needed for running experiments that use octave.

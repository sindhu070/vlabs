function dij=delta(i,j)
    if(i==j)
        dij=1;
    else
        dij=0;
    end
return
<html>

<h3>Solution to optimization problems</h3>

<h3>Hopfiled feedback neural networks for optimization problems</h3>

<ul>
<li><a href=graphbipartition.php>Graph bipartition problem</a></li><br>
<li><a href=tsp.php>Travelling salesman problem</li><br>
</ul>

</html>
